package com.Literalura.proyectoLAVR;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoLavrApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoLavrApplication.class, args);
	}

}
